import os
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}
# Реальные платежи и выдача намеренно отключены в стартовом шаблоне.
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"
