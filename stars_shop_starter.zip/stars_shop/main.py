import asyncio
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from config import BOT_TOKEN
from database import init_db
from handlers.start import router as start_router
from handlers.shop import router as shop_router
from handlers.admin import router as admin_router

async def main():
    if not BOT_TOKEN:
        raise RuntimeError("Заполни BOT_TOKEN в .env")
    await init_db()
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(start_router)
    dp.include_router(shop_router)
    dp.include_router(admin_router)
    print("STARS SHOP запущен в DEMO-режиме.")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
