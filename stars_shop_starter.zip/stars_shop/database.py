import aiosqlite
from pathlib import Path

DB_PATH = Path("data/shop.db")

async def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            stars_amount INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending_demo',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """)
        await db.commit()

async def create_order(user_id: int, username: str | None, amount: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO orders(user_id, username, stars_amount) VALUES (?, ?, ?)",
            (user_id, username, amount)
        )
        await db.commit()
        return cur.lastrowid

async def get_user_orders(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, stars_amount, status, created_at FROM orders "
            "WHERE user_id=? ORDER BY id DESC LIMIT 10", (user_id,)
        )
        return await cur.fetchall()

async def get_recent_orders(limit: int = 20):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, user_id, username, stars_amount, status, created_at "
            "FROM orders ORDER BY id DESC LIMIT ?", (limit,)
        )
        return await cur.fetchall()

async def set_order_status(order_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        await db.commit()
