"""
Заглушка платёжного слоя.
Не принимайте реальные деньги, пока не выбраны законный платёжный сценарий,
провайдер и корректная схема продажи с учётом правил Telegram.
"""
class PaymentService:
    async def create_payment(self, order_id: int, amount_minor: int):
        raise NotImplementedError(
            "Реальные платежи отключены. Сначала настройте совместимого провайдера."
        )

    async def verify_payment(self, provider_event: dict) -> bool:
        # В production проверяйте подпись webhook и сумму/валюту/ID заказа
        # на сервере. Никогда не доверяйте скриншоту от пользователя.
        raise NotImplementedError("Проверка реальных платежей не настроена.")
