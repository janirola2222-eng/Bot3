from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

PACKS = [50, 100, 250, 500, 1000]

def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ Купить Stars", callback_data="shop")],
        [InlineKeyboardButton(text="📦 Мои заказы", callback_data="my_orders")],
        [InlineKeyboardButton(text="ℹ️ Информация", callback_data="info")]
    ])

def catalog():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"⭐ {n} Stars", callback_data=f"buy:{n}")]
        for n in PACKS
    ] + [[InlineKeyboardButton(text="⬅️ Главное меню", callback_data="home")]])
