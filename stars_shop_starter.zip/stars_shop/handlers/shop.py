from aiogram import Router, F
from aiogram.types import CallbackQuery
from keyboards.main import catalog, main_menu
from database import create_order, get_user_orders

router = Router()

@router.callback_query(F.data == "shop")
async def show_shop(callback: CallbackQuery):
    await callback.message.edit_text(
        "⭐ <b>Каталог Stars</b>\n\nВыберите пакет для создания тестового заказа:",
        reply_markup=catalog()
    )
    await callback.answer()

@router.callback_query(F.data.startswith("buy:"))
async def create_demo_order(callback: CallbackQuery):
    amount = int(callback.data.split(":")[1])
    order_id = await create_order(
        callback.from_user.id,
        callback.from_user.username,
        amount
    )
    await callback.message.edit_text(
        f"🧾 <b>Тестовый заказ №{order_id}</b>\n\n"
        f"Количество: <b>{amount} Stars</b>\n"
        "Статус: <b>создан (DEMO)</b>\n\n"
        "Оплата и выдача в этом шаблоне не выполняются.",
        reply_markup=main_menu()
    )
    await callback.answer("Тестовый заказ создан")

@router.callback_query(F.data == "my_orders")
async def my_orders(callback: CallbackQuery):
    rows = await get_user_orders(callback.from_user.id)
    if not rows:
        text = "📦 <b>Мои заказы</b>\n\nЗаказов пока нет."
    else:
        lines = ["📦 <b>Последние заказы</b>"]
        for oid, amount, status, created in rows:
            lines.append(f"№{oid} · {amount} ⭐ · {status} · {created}")
        text = "\n".join(lines)
    await callback.message.edit_text(text, reply_markup=main_menu())
    await callback.answer()
