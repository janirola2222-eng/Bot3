from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from keyboards.main import main_menu

router = Router()

@router.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "⭐ <b>STARS SHOP</b>\n\n"
        "Добро пожаловать! Здесь можно посмотреть каталог и создать тестовый заказ.\n"
        "<i>Сейчас включён демонстрационный режим: реальные платежи и зачисление Stars отключены.</i>",
        reply_markup=main_menu()
    )

@router.callback_query(F.data == "home")
async def home(callback: CallbackQuery):
    await callback.message.edit_text("⭐ <b>STARS SHOP</b>\nВыберите раздел:", reply_markup=main_menu())
    await callback.answer()

@router.callback_query(F.data == "info")
async def info(callback: CallbackQuery):
    await callback.message.edit_text(
        "ℹ️ <b>Информация</b>\n\n"
        "Это демонстрационный магазин. Создание заказа не означает оплату или зачисление Stars.\n"
        "Не отправляйте никому пароль, код входа или QR-код своего Telegram-аккаунта.",
        reply_markup=main_menu()
    )
    await callback.answer()
