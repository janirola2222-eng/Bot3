from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from config import ADMIN_IDS
from database import get_recent_orders

router = Router()

@router.message(Command("admin"))
async def admin(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("⛔ Нет доступа.")
        return
    rows = await get_recent_orders()
    if not rows:
        await message.answer("Заказов пока нет.")
        return
    lines = ["🛠 <b>Последние заказы (DEMO)</b>"]
    for oid, uid, username, amount, status, created in rows:
        user = f"@{username}" if username else f"ID {uid}"
        lines.append(f"№{oid} | {user} | {amount} ⭐ | {status} | {created}")
    await message.answer("\n".join(lines))
